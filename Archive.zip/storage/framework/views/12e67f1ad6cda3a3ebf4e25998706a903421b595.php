<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> کوئرا </title>
</head>
<body>
<?php echo e(__('admin::admin.list', ['value' => trans_choice('admin::admin.user', 2)])); ?>

</body>
</html>
<?php /**PATH /Users/adibov/PhpstormProjects/Laravel-Course/9,10,15,22,26,27-CMS/CMS-laravel9/CMS/Modules/Admin/Resources/views/users/index.blade.php ENDPATH**/ ?>