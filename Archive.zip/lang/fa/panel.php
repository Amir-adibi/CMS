<?php

return [

    'quera' => 'کوئرا',
    'made_with' => 'ساخته شده توسط',
    'about_us' => 'درباره‌ما',

];
